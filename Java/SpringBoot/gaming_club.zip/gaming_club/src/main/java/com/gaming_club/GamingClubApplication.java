package com.gaming_club;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamingClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamingClubApplication.class, args);
	}

}
